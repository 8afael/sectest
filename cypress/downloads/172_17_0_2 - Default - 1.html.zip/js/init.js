jQuery.fn.exists = function(){ return this.length > 0; };

$.expr[':'].icontains = function(obj, index, meta, stack){
    return (obj.textContent || obj.innerText || jQuery(obj).text() || '').
        toLowerCase().indexOf(meta[3].toLowerCase()) >= 0;
};

jQuery(function ($) {
    // Init all tooltips.
    $("[rel=tooltip]").tooltip();

    if( !window.location.hash.split('#!/')[1] ) {
        goToLocation( 'summary/charts' );
    }

    // Restore the last open tab from the URL fragment.
    openFromWindowLocation();
    scrollToActiveElementFromWindowLocation();
});

$(window).bind( 'hashchange', function () {
    openFromWindowLocation();
});
